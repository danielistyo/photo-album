import AlbumPhoto from "./AlbumPhoto";

export default AlbumPhoto;
