import AlbumCard from "./AlbumCard";

export default AlbumCard;
